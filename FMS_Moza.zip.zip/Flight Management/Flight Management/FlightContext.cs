﻿using System;
using Flight_Management.Models;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Flight_Management
{

    //system storage
    public class FlightContext
    {
        public List <Pilot> pilots { get; set; }
        public List<Passenger> passengers { get; set; }
        public List<Flight> flights { get; set; }
        public List<Booking> bookings { get; set; }
        public List<Aircraft> aircrafts { get; set; }

    }
}
