﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight_Management.Models
{
    public class Booking
    {
        public int bookingId { get; set; }  //System Generated
        public int passengerId { get; set; }  //From List
        public int flightId { get; set; }   //From List
        public string seatNumber { get; set; }   //User Input
        public string bookingDate { get; set; }  //User Input
        public decimal totalPrice { get; set; }  //Calculated
        public string status { get; set; }  //Default Value


    }
}
