﻿using Flight_Management.Models;
using System.Numerics;

namespace Flight_Management
{
    public class Program
    {
        //system storage ( actual storage in memory for all lists ) 
        public static FlightContext context = new FlightContext
        {
            pilots = new List<Pilot>(),
            passengers = new List<Passenger>(),
            flights = new List<Flight>(),
            bookings = new List<Booking>(),
            aircrafts = new List<Aircraft>()
        };

        //01 Register a Passenger
        public static void RegisterPassenger(FlightContext context)
        {
            Console.WriteLine("\n === Register Passenger ===");

            Console.WriteLine("Enter Passenger Name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter passenger Email: ");
            string email = Console.ReadLine();

            Console.WriteLine("Enter passenger Phone: ");
            string phone = Console.ReadLine();

            Console.WriteLine("Enter passenger Number: ");
            string passengerNumber = Console.ReadLine();

            Console.WriteLine("Enter nationality (Omani/Egyptian/Saudi/Others): ");
            string nationality = Console.ReadLine();

            int passengerId = context.passengers.Count + 1; //calculated

            context.passengers.Add(new Passenger
            {
                passengerId = passengerId,
                passengerName = name,
                passengerEmail = email,
                passengerPhone = phone,
                passengerNumber = passengerNumber,
                nationality = nationality,
            }
            );
            Console.WriteLine($"Passenger Added Successfully. Assigned ID: {passengerId}");
        }


        
        //02 Add an Aircraft
        public static void AddAircraft(FlightContext context)
        {

            Console.WriteLine("\n=== Add New Aircraft ===");

            Console.WriteLine("Enter aircraft model:");
            string model = Console.ReadLine();

            Console.WriteLine("Enter total seats:");
            int totalSeats = int.Parse(Console.ReadLine());

            int aircraftId = context.aircrafts.Count + 1;
            
            context.aircrafts.Add(new Aircraft
            {

            aircraftId = aircraftId,
            model = model,
            totalSeats = totalSeats,
            isOperational = true,

            });

            Console.WriteLine($"aircraft added successfully with AircraftId: {aircraftId}");

        }

        
        //03 Register a Pilot

        public static void RegisterPilot(FlightContext context)
        {

            Console.WriteLine("\n=== Register Pilot ===");

            Console.WriteLine("Enter Pilot Name:");
            string pilotName = Console.ReadLine();

            Console.WriteLine("Enter Pilot Phone:");
            string pilotPhone = Console.ReadLine();

            Console.WriteLine("Enter License Number:");
            string licenseNumber = Console.ReadLine();

            int pilotId = context.pilots.Count + 1; // System Generated

            context.pilots.Add(new Pilot
            {
                pilotId = pilotId,
                pilotName = pilotName,
                pilotPhone = pilotPhone,
                licenseNumber = licenseNumber,
                flightHours = 0,      
                isAvailable = true    
            });

            Console.WriteLine($"Pilot Added Successfully. Assigned ID: {pilotId}");
        }


        
       // 04 View All Flights
        public static void ViewAllFlights(FlightContext context)
        {
            Console.WriteLine("\n*** ALL Flights ***");
  

            foreach (Flight f in context.flights)
            {
                Console.WriteLine(
                    $"Flight Code: {f.flightCode}  |  " +
                    $"Origin: {f.origin}  |  " +
                    $"Destination: {f.destination}  |  " +
                    $"Date: {f.departureDate}  |  " +
                    $"Time: {f.departureTime}  |  " +
                    $"Available Seats: {f.availableSeats}  |  " +
                    $"flight Duration: {f.flightDuration}" +
                    $"Ticket Price: {f.ticketPrice}  |  " +
                    $"Status: {f.status}"
                );
            }
        }
        
        //05 Schedule a Flight
        public static void ScheduleFlight(FlightContext context)
        {
            Console.WriteLine("\n=== Schedule Flight ===");

            Console.WriteLine("Enter Aircraft ID:");
            int aircraftId = int.Parse(Console.ReadLine());

            Aircraft aircraft = context.aircrafts .FirstOrDefault(a => a.aircraftId == aircraftId);

            if (aircraft == null || aircraft.isOperational == false)
            {
                Console.WriteLine("Aircraft not available.");
                return;
            }

            Console.WriteLine("Enter Pilot ID:");
            int pilotId = int.Parse(Console.ReadLine());

            Pilot pilot = context.pilots
                .FirstOrDefault(p => p.pilotId == pilotId);

            if (pilot == null || pilot.isAvailable == false)
            {
                Console.WriteLine("Pilot not available.");
                return;
            }

            Console.WriteLine("Enter Origin:");
            string origin = Console.ReadLine();

            Console.WriteLine("Enter Destination:");
            string destination = Console.ReadLine();

            Console.WriteLine("Enter Departure Date:");
            string departureDate = Console.ReadLine();

            Console.WriteLine("Enter Departure Time:");
            string departureTime = Console.ReadLine();

            Console.WriteLine("Enter Flight Duration:");
            int flightDuration = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Ticket Price:");
            decimal ticketPrice = decimal.Parse(Console.ReadLine());

            int flightId = context.flights.Count + 1;

            string flightCode = "FL" + flightId;

            context.flights.Add(new Flight
            {
                flightId = flightId,
                flightCode = flightCode,
                aircraftId = aircraftId,
                flightDuration = flightDuration,
                pilotId = pilotId,
                origin = origin,
                destination = destination,
                departureDate = departureDate,
                departureTime = departureTime,
                ticketPrice = ticketPrice,
                availableSeats = aircraft.totalSeats,
                status = "Scheduled"
            });

            pilot.isAvailable = false;

            Console.WriteLine($"Flight Scheduled Successfully with Code {flightCode}");
        }


        //06 Book a Flight

        public static void BookFlight(FlightContext context)

        {
            Console.WriteLine("\n=== Book a Flight ===");

            Console.WriteLine("Enter Passenger ID:");
            int passengerId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Destination:");
            string destination = Console.ReadLine();

            List<Flight> availableFlights = context.flights
                .Where(f => f.destination == destination
                         && f.status == "Scheduled"
                         && f.availableSeats > 0)
                .ToList();

            Console.WriteLine("\nAvailable Flights:");

            foreach (Flight f in availableFlights)
            {
                Console.WriteLine($"Flight ID: {f.flightId} | Code: {f.flightCode} | Date: {f.departureDate} | Time: {f.departureTime} | Seats: {f.availableSeats} | Price: {f.ticketPrice}");
            }

            Console.WriteLine("\nEnter Flight ID to book:");
            int flightId = int.Parse(Console.ReadLine());

            Flight selectedFlight = availableFlights .FirstOrDefault(f => f.flightId == flightId);

            if (selectedFlight == null)
            {
                Console.WriteLine("Invalid Flight Selection!");
                return;
            }

            int bookingId = context.bookings.Count + 1;

            string seatNumber = "S" + bookingId;

            string bookingDate = DateTime.Now.ToString("yyyy-MM-dd");

            decimal totalPrice = selectedFlight.ticketPrice;

            context.bookings.Add(new Booking
            {
                bookingId = bookingId,          // System Generated
                passengerId = passengerId,      // From List
                flightId = flightId,            // From List
                seatNumber = seatNumber,      
                bookingDate = bookingDate,      // System generated
                totalPrice = totalPrice,        // Calculated 
                status = "Confirmed"            // Default value
            });

            selectedFlight.availableSeats = selectedFlight.availableSeats - 1; ;

            Console.WriteLine("\nBooking Successful!");
            Console.WriteLine($"Booking ID: {bookingId}");
            Console.WriteLine($"Seat Number: {seatNumber}");
            Console.WriteLine($"Total Price: {totalPrice}");
        
        }

        //07 Cancel a Booking
        public static void CancelBooking(FlightContext context)
        {
            Console.WriteLine("\n=== Cancel a Booking ===");

            Console.WriteLine("Enter Booking ID:");
            int bookingId = int.Parse(Console.ReadLine());

            Booking booking = context.bookings.FirstOrDefault(b => b.bookingId == bookingId);

            if (booking == null)
            {
                Console.WriteLine("Booking not found!");
                return;
            }

            if (booking.status == "Cancelled")
            {
                Console.WriteLine("Booking is already cancelled!");
                return;
            }

            Flight flight = context.flights.FirstOrDefault(f => f.flightId == booking.flightId);

            booking.status = "Cancelled";

            if (flight != null)
            {
                flight.availableSeats = flight.availableSeats + 1;
            }

            Console.WriteLine("\nBooking Cancelled Successfully!");
            Console.WriteLine($"Booking ID: {booking.bookingId}");
        }


            
          //08 Depart a Flight
        public static void DepartFlight(FlightContext context)
        {
            Console.WriteLine("\n=== Depart a Flight ===");

            Console.WriteLine("Enter Flight ID:");
            int flightId = int.Parse(Console.ReadLine());

            Flight flight = context.flights .FirstOrDefault(f => f.flightId == flightId);

            if (flight == null)
            {
                Console.WriteLine("Flight not found!");
                return;
            }

            if (flight.status == "Departed")
            {
                Console.WriteLine("Flight already departed!");
                return;
            }

            if (flight.status == "Cancelled")
            {
                Console.WriteLine("Cannot depart a cancelled flight!");
                return;
            }

            Pilot pilot = context.pilots .FirstOrDefault(p => p.pilotId == flight.pilotId);



            if (pilot != null)
            {
                pilot.flightHours = pilot.flightHours + flight.flightDuration;
                
                pilot.isAvailable = true;
            }
            

            

            Console.WriteLine($"Flight Departed Successfully! | Flight Code: {flight.flightCode} | Status: {flight.status}");
            

        }

        

        //09 Cancel a Flight
        public static void CancelFlight(FlightContext context)
        {
            Console.WriteLine("\n===== Cancel Flight =====");

            Console.Write("Enter Flight ID: ");
            int flightId = int.Parse(Console.ReadLine());

            Flight f = context.flights.FirstOrDefault(f => f.flightId == flightId);

            if (f == null)
            {
                Console.WriteLine("Flight not found!");
                return;
            }

            int affectedBookings = 0;

            foreach (Booking booking in context.bookings)
            {
                if (booking.flightId == flightId &&
                    booking.status == "Confirmed")
                {
                    booking.status = "Cancelled";
                    affectedBookings++;
                }
            }

            Pilot pilot = context.pilots.FirstOrDefault(p => p.pilotId == f.pilotId);

            if (pilot != null)
            {
                pilot.isAvailable = true;
            }

            f.status = "Cancelled";

            Console.WriteLine($"Flight {f.flightCode} has been cancelled.");
            Console.WriteLine($"{affectedBookings} bookings were affected.");
        }

         

        //10 Passenger Booking History
        public static void PassengerBookingHistory(FlightContext context)
        {
            Console.WriteLine("\n=== Passenger Booking History ===");

            Console.WriteLine("Enter Passenger ID:");
            int passengerId = int.Parse(Console.ReadLine());

            decimal totalSpent = 0;

            foreach (Booking booking in context.bookings)
            {
                if (booking.passengerId == passengerId)
                {
                    Flight flight = context.flights  .FirstOrDefault(f => f.flightId == booking.flightId);

                    if (flight != null)
                    {
                        Console.WriteLine(
                            $"Flight Code: {flight.flightCode} " +
                            $"Origin: {flight.origin}  " +
                            $"Destination: {flight.destination}" +
                            $"Departure Date: {flight.departureDate} " +
                            $"Seat Number: {booking.seatNumber} " +
                            $"Price Paid: {booking.totalPrice}  " +
                            $"Status: {booking.status}");

                        if (booking.status == "Confirmed")
                        {
                            totalSpent += booking.totalPrice;
                        }
                    }
                }
            }

            Console.WriteLine($"\nTotal Amount Spent: {totalSpent}");
        }
        

        //11 Flight Revenue & Load Factor Report
        public static void FlightRevenueAndLoadFactorReport (FlightContext context)
        {
            Console.WriteLine("\n=== Flight Revenue & Load Factor Report ===");

            decimal grandTotalRevenue = 0;

            var report = context.flights .Select(flight =>
                {
                    int confirmedBookings = 0;
                    decimal revenue = 0;

                    foreach (Booking booking in context.bookings)
                    {
                        if (booking.flightId == flight.flightId &&
                            booking.status == "Confirmed")
                        {
                            confirmedBookings++;
                            revenue += booking.totalPrice;
                        }
                    }

                    Aircraft aircraft = context.aircrafts .FirstOrDefault(a => a.aircraftId == flight.aircraftId);

                    int totalSeats = aircraft.totalSeats;

                    decimal loadFactor =
                        (decimal)confirmedBookings / totalSeats * 100;

                    return new
                    {
                        FlightCode = flight.flightCode,
                        Route = flight.origin + " -> " + flight.destination,
                        ConfirmedBookings = confirmedBookings,
                        Revenue = revenue,
                        LoadFactor = loadFactor
                    };
                })
                .OrderByDescending(r => r.Revenue)
                .ToList();

            foreach (var item in report)
            {
                Console.WriteLine(
                    $"Flight Code: {item.FlightCode}" +
                    $"Route: {item.Route} " +
                    $"Confirmed Bookings: {item.ConfirmedBookings} " +
                    $"Revenue: {item.Revenue} " +
                    $"Load Factor: {item.LoadFactor:F2}%");

                grandTotalRevenue += item.Revenue;
            }

            Console.WriteLine($"\nGrand Total Revenue: {grandTotalRevenue}");
        

        }

        
            // MAIN — Menu Loop

            static void Main(string[] args)
            {
                
                bool exit = false;
                while (exit == false)
                {
                    //let the system begin 
                    Console.WriteLine("\n-----------------------------");
                    Console.WriteLine("Welcome to the Flight Management System!");
                    Console.WriteLine("-----------------------------");
                    Console.WriteLine("1-RegisterPassenger  ");
                    Console.WriteLine("2- AddAircraft");
                    Console.WriteLine("3- RegisterPilot");
                    Console.WriteLine("4- ScheduleFlight");
                    Console.WriteLine("5- ViewAllFlights");
                    Console.WriteLine("6- BookFlight");
                    Console.WriteLine("7- CancelBooking");
                    Console.WriteLine("8- DepartFlight");
                    Console.WriteLine("9 -CancelFlight ");
                    Console.WriteLine("10- PassengerBookingHistory");
                    Console.WriteLine("11- FlightRevenueAndLoadFactorReport");
                    Console.WriteLine("0- Exit");
                    Console.WriteLine("-----------------------------");

                    Console.WriteLine("Please select an option:");

                    int option = int.Parse(Console.ReadLine());

                    switch (option)
                    {
                        case 1:
                        // code for RegisterPatient
                        RegisterPassenger(context);
                            break;

                        case 2:
                        // code for add Doctor
                        AddAircraft(context);
                            break;

                        case 3:
                        // code for ViewAllPatients
                        RegisterPilot(context);
                            break;

                        case 4:
                        // code for AddAvailableSlot
                        ScheduleFlight(context);

                        break;

                        case 5:

                        // code for ViewAllDoctorsBySpecialization
                        ViewAllFlights(context);
                        
                            break;

                        case 6:
                        // code for BookAppointment
                        BookFlight(context);
                            break;

                        case 7:
                        // code for view reviews
                        CancelBooking(context);
                            break;

                        case 8:
                        //code for CreateMedicalRecord
                        DepartFlight(context);
                            break;

                        case 9:
                        //code for GeneratePatientMedicalHistory 
                        CancelFlight(context);
                            break;

                        case 10:
                        //code for DoctorWorkloadAndRevenueSummary
                        PassengerBookingHistory(context);
                            break;
                    case 11:
                        //code for FlightRevenueAndLoadFactorReport
                        FlightRevenueAndLoadFactorReport (context);
                        break;

                    case 0:
                            exit = true;
                            break;

                        default:
                            Console.WriteLine("Invalid option. Please try again.");
                            break;

                    }

                    if (!exit)
                    {

                        Console.WriteLine("Press any key to continue...");
                        Console.ReadKey();// to wait for user input before clearing the console
                        Console.Clear();
                    }
                }

                Console.WriteLine("Goodbye!");


            }


        }
    }



    
